from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from myapp.forms import employeePost,productPost
from myapp.models import employee,product
# Create your views here.
def index(request):
    return render(request,'br1.html')
def disp_list(request):
    posts=employee.objects.all()
    return render(request,'br3.html',{'posts':posts})
    
def add_list(request):
    if request.method=='POST':
        form=employeePost(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Index')
    else:
        form=employeePost()
    return render(request,'br2.html',{'forms':form})
def del_list(request):
    posts=employee.objects.all()
    return render(request,'br8.html',{'posts':posts})
def dele_list(request,id):
    items=get_object_or_404(employee,id=id)
    items.delete()
    return redirect('Delete Employee')
def addProduct(request):
    if request.method=='POST':
        form=productPost(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Index')
    else:
        form=productPost()
    return render(request,'br5.html',{'forms':form})
def sold_items(request):
    posts=product.objects.all()
    return render(request,'br9.html',{'posts':posts})
def update_items(request,id):
    #items=get_object_or_404(product,id=id)
    if request.method=='POST':
        form=employeePost(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Index')
    else:
        form=employeePost()
    return render(request,'br2.html',{'forms':form})
def stock(request):
    posts=product.objects.all()
    return render(request,'br7.html',{'posts':posts})
def product_stock(request):
    posts=product.objects.all()
    return render(request,'br6.html',{'posts':posts})


