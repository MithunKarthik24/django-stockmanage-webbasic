from django import forms
from myapp.models import employee,product
class employeePost(forms.ModelForm):
    class Meta:
        model=employee
        fields='__all__'

class productPost(forms.ModelForm):
    class Meta:
        model=product
        fields='__all__'
