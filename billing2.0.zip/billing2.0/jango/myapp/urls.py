from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name="Index"),
    path('empdisp/',views.disp_list,name="Display Employee"),
    path('addemp/',views.add_list,name="Add Employee"),
    path('delemp/',views.del_list,name="Delete Employee"),
    path('delemp/<int:id>',views.dele_list,name="Delete Specific Employee"),
    path('addPrd/',views.addProduct,name="Add Product"),
    path('sld/',views.sold_items,name="Sold Items"),
    path('stk/',views.stock,name="Total Stock"),
    path('prodstk/',views.product_stock,name="Current Stock"),
    path('update/<int:id>',views.update_items,name="Update")
    ]
