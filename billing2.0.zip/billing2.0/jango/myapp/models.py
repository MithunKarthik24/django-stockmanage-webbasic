from django.db import models

# Create your models here.
class employee(models.Model):
    Choice=[
        ('Manager','Manager'),
        ('Supervisor','Supervisor'),
        ('Seller','Seller'),
        ('Cashier','Cashier'),
        ('Cleaner','Cleaner'),
        ('Security','Security'),
        ]
    name=models.CharField(max_length=30)
    emp_no=models.IntegerField()
    designation=models.CharField(max_length=30,choices=Choice)

    def __str__(self):
        return self.name

class product(models.Model):
    #product_id=models.IntegerField()
    mobile_number=models.IntegerField()
    product_name=models.CharField(max_length=30)
    category=models.CharField(max_length=30)
    quantity=models.IntegerField()
    mrp=models.IntegerField()
    discount_percent=models.IntegerField()

    def __str__(self):
        return self.product_name
    
